module.exports = "left-pad@1.0.0";
