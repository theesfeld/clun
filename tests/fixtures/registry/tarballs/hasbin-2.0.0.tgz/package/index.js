module.exports = "hasbin@2.0.0";
