#!/bin/sh
mkdir -p dist
echo "// built by hasbin@2.0.0" > dist/bundle.js
echo "hasbin: wrote dist/bundle.js"
