module.exports = "conflict-a@1.0.0";
