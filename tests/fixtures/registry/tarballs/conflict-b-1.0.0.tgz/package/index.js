module.exports = "conflict-b@1.0.0";
