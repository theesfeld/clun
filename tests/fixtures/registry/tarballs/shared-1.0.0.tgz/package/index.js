module.exports = "shared@1.0.0";
