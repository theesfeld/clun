module.exports = "@scope/widget@1.0.0";
