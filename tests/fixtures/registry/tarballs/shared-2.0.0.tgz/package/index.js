module.exports = "shared@2.0.0";
