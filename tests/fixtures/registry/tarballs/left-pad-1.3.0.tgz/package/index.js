module.exports = "left-pad@1.3.0";
