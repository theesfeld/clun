module.exports = "left-pad@1.1.0";
